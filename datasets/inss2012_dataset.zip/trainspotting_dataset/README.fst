Author: Eugen Berlin, Embedded Sensing Systems, Technische Universität Darmstadt

Data set website: http://www.ess.tu-darmstadt.de/datasets/inss2012-trainspotting

Eugen Berlin and Kristof Van Laerhoven, "Trainspotting: Combining Fast Features
to Enable Detection on Resource-constrained Sensing Devices". In Proceedings of 
the 9th International Conference on Networked Sensing Systems (INSS 2012), 
Antwerp, Belgium. IEEE Press. 2012


IMPORTANT NOTE
--------------

This data set is opened up to anyone interested in activity recognition to 
encourage reproducible results. Please cite our paper if you publish results 
on this data set, and consider making your own data sets open for anyone to 
download in a similar fashion. We would also be very interested to hear back 
from you if you use our data in any way and are happy to answer any questions 
or address any remarks related to it. 


DATA SET CONTENTS
-----------------

This data set contains more than 36 hours of raw accelerometer sensor data, 
recorded with our HedgeHog sensor, stored as numerical python data format (npy).
The data set consists of two parts: 1) main track features different train types 
and number of wagons, 2) regional city hopper train track, where only one type 
of train is running, but the number of wagons varies between 1 and 3.

Additionally, the data set contains annotation files. The first track was 
annotated by labeling know train types as follows:
	1:'ICE', 2: 'IC', 3: 'EC', 4: 'Cargo', 5: 'RE', 6: 'RB'
ICE, IC, and EC are fast passenger trains. IC and EC trains only differ by name,
but share the same type of locomotive and wagons. RE and RB are regional 
passenger train types. Cargo stands for the very diverse cargo train class.


LOADING DATA
------------

To load the data we need to import the numpy library and issue the load command:

>>> import numpy as np
>>> dta1 = np.load('data/train_1.npy').view(np.recarray)
>>> dta2 = np.load('data/train_2.npy').view(np.recarray)
>>> lbl1 = np.load('data/train_1_lbl.npy')
>>> lbl2 = np.load('data/train_2_lbl.npy')

The 'dta' variables now hold a record array with following columns:
  dta.t - time stamp in ordinal format
  dta.d - runlength encoding - delta values
  dta.x - accelerometer X-axis
  dta.y - accelerometer Y-axis
  dta.z - accelerometer Z-axis
  dta.l - ambient light sensor
  
The 'lbl' variables hold the start and stop time indices of the event, as well 
as the train type ID (main track) or the number of wagons (regional track).


PLOTTING DATA
-------------

For plotting, we use the matplotlib pyplot library in its interactive mode:

>>> import matplotlib.pyplot as plt
>>> plt.ion()

Now, to plot accelerometer sensor data (all three axes at once) against time, 
we can use the pyplot plot_date() function. It will automatically convert the 
ordinal date to a human readable date format:

>>> plt.plot_date( dta1.t , np.array((dta1.x,dta1.y,dta1.z)).T , '-')
>>> plt.ylim([0,255])

You can use the zoom/pan functions of the GUI to investigate the differences 
and similarities within and accross train type classes. For highlighting the 
known train events and displaying their labels, we can use:

>>> traintypes = {1:'ICE', 2: 'IC', 3: 'EC', 4: 'Cargo', 5: 'RE', 6: 'RB'}
>>> for s,e,l in lbl1:
		plt.axvspan( dta1.t[s], dta1.t[e], facecolor='r', alpha=0.25 )
		plt.text(dta1.t[s],230,traintypes[l])


See plot_data.py file for more examples.

