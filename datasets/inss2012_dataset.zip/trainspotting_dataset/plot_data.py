import numpy as np
import matplotlib.pyplot as plt
#~ import matplotlib.mlab as mlab

# load sensor data
dta1 = np.load('data/train_1.npy').view(np.recarray)
dta2 = np.load('data/train_2.npy').view(np.recarray)

# load annotations
lbl1 = np.load('data/train_1_lbl.npy')	# different train types
lbl2 = np.load('data/train_2_lbl.npy')	# same type, varying no. of wagons

# load detailed annotations for main track
#~ timetable = mlab.csv2rec('data/timetable.csv',delimiter=';')
traintypes = {1:'ICE', 2: 'IC', 3: 'EC', 4: 'Cargo', 5: 'RE', 6: 'RB'}

# plot main track data and mark annotated (known) trains
fig = plt.figure(num=None,figsize=(14,3.5),dpi=85,facecolor='w',edgecolor='k')
ax1 = plt.subplot(1,1,1)
ax1.plot_date( dta1.t , np.array((dta1.x,dta1.y,dta1.z)).T , '-')
plt.ylim([0,255])
for s,e,l in lbl1:
    ax1.axvspan( dta1.t[s], dta1.t[e], facecolor='r', alpha=0.15)
    ax1.text(dta1.t[s],230,traintypes[l])
plt.subplots_adjust(left=0.04,right=0.99,bottom=0.09,top=0.93,wspace=0.05,hspace=0.1)
plt.show()

# plot city hopper track data 
fig = plt.figure(num=None,figsize=(14,3.5),dpi=85,facecolor='w',edgecolor='k')
ax1 = plt.subplot(1,1,1)
plt.plot_date( dta2.t , np.array((dta2.x,dta2.y,dta2.z)).T , '-')
plt.ylim([0,255])
for s,e,l in lbl2:
    ax1.axvspan( dta2.t[s], dta2.t[e], facecolor='r', alpha=0.15)
    ax1.text(dta2.t[s],230,l)
plt.subplots_adjust(left=0.04,right=0.99,bottom=0.09,top=0.93,wspace=0.05,hspace=0.1)
plt.show()

