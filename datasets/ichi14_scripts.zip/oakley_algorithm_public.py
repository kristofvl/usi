# oakley_algo.py
# author: Marko Borazio for ESS, TU Darmstadt
# March 2014
# description:
# Sleep/wake estimation by Oakley's algorithm (Actiwatch)

import numpy as np
import sleeplab_helper as slh

###------------------------------------------------------------------###
def oakley(dta, srate, elength, aw_tresh):
	ac = oakley_ac(dta, srate, elength) # calculate activity count
	
	ws_arr = np.zeros(len(ac),'uint8')
	A = np.zeros(len(ac))
	for j, val in enumerate(ac):
		if (j+8) >= len(ac):
			break
		
		#estimate sleep/awake by Oakley's algorithm
		A[j+4] = (ac[j]+ac[j+1])*0.04 + (ac[j+2]+ac[j+3])*0.2 + 2*ac[j+4] + (ac[j+5]+ac[j+6])*0.2 + (ac[j+7]+ac[j+8])*0.04
		
		if A[j+4] < aw_tresh:
			#sleep
			ws_arr[j+4] = 1
	
	return ws_arr, A, ac

###------------------------------------------------------------------###
def oakley_ac(dta, srate, elength):
	#calculate activity count
	ac = []
	for i in range(1,(dta.shape[0]-elength*srate),elength*srate):
		act = dta['z'][i:(i+elength*srate)]
		act = act.reshape([elength, srate])
		
		#calculate maximum absolute values for one epoch
		act = np.max(abs(act),1)
		
		#scale maximum absolute values according to Virkkala [66, -3.3] to get activity count
		act = act * 66 - 3.3
		act[act<0] = 0
		act = np.sum(act)
		ac.append(act)
	
	return ac

###------------------------------------------------------------------###

###---MAIN---###
# calculate activity count as described by Virkkala for the Actiwatch 
# activity count comparison to HHG data

hhgpath = 'put the path to the HedgeHog data here'
annopath = 'put the path to the annotation file here'

srate = 100 # sampling @ 100 Hz
elength = 30 #epoch length
threshold = [20] #actiwatch treshold
fs = 100.0
lowcut = 3.0
highcut = 11.0
order = 1
ing = True

usrlist = slh.get_userlist()

	tot = np.zeros(len(usrlist),int)
	slp = np.zeros([len(usrlist)+2,5],float)
for i, usrno in enumerate(usrlist):
	print usrno
	hhgdta = np.load("%sp%s.npy"%(hhgpath,usrno))
	hhgraw = slh.rle2raw(hhgdta)
	gtdta = np.load("%sp%s_anno.npy"%(annopath,usrno))
		
	# filter data
	sfiltered = slh.butterworth(hhgraw[:,2:5], fs, lowcut, highcut, order, ing)
		
	try:
		# sleep estimation
		[swest, A, ac] = oakley(sfiltered, srate, elength, threshold)
			
	except (ZeroDivisionError,ValueError,RuntimeWarning) as e:
		print '##########---error:' , e
		continue