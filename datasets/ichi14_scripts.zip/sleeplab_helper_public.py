# sleeplab_helper.py
# author: Marko Borazio for ESS, TU Darmstadt
# March 2014
# description:
# Helper functions for the sleep lab study

import numpy as np
from pylab import *
from scipy.signal import butter, lfilter

###------------------------------------------------------------------###
def get_userlist():
	return [\
			'002','003','005','007','08a','08b', '09a','09b',\
			'10a','011','013','014','15a','15b','016','017','018','019',\
			'020','021','022','023','025','026','027','028','029',\
			'030','031','032','033','034','035','036','037','038',\
			'040','042','043','044','045','047','048','049',\
			'051_hl','051_hr']

###------------------------------------------------------------------###
# butterworth high pass filter functions
def butter_bandpass(lowcut, highcut, fs, order):
	nyq = 0.5 * fs
	low = lowcut / nyq
	high = highcut / nyq
	b, a = butter(order, [low, high], btype='band')
	return b, a

def butter_bandpass_filter(data, lowcut, highcut, fs, order):
	b, a = butter_bandpass(lowcut, highcut, fs, order)
	y = lfilter(b, a, data)
	return y

def butterworth(hhgraw, fs, lowcut, highcut, order, ing):
	y = np.array(np.zeros(hhgraw.shape[0]),
					dtype=np.dtype([('x', 'float'),
									('y', 'float'),
									('z', 'float')]))
	#filter raw data (bandpass filter)
	if ing:
		y['x'] = butter_bandpass_filter(convert2g(convert2signed(hhgraw[:,0])), lowcut, highcut, fs, order)
		y['y'] = butter_bandpass_filter(convert2g(convert2signed(hhgraw[:,1])), lowcut, highcut, fs, order)
		y['z'] = butter_bandpass_filter(convert2g(convert2signed(hhgraw[:,2])), lowcut, highcut, fs, order)
	else:
		y['x'] = butter_bandpass_filter(convert2signed(hhgraw[:,0]), lowcut, highcut, fs, order)
		y['y'] = butter_bandpass_filter(convert2signed(hhgraw[:,1]), lowcut, highcut, fs, order)
		y['z'] = butter_bandpass_filter(convert2signed(hhgraw[:,2]), lowcut, highcut, fs, order)
	return y

def convert2signed(dta):
	return np.array(np.int_(dta)^0x80, dtype='int8')

def convert2g(dta):
	return dta*0.03125-4 # ((x*8.0)/2**8)-4

###------------------------------------------------------------------###
#convert from runlength encoding (RLE) to raw data
def rle2raw(dta):
	# extract RLE encoded acceleration data
	rle = np.array((dta['d'],dta['t'],[1]*dta.shape[0],dta['x'],dta['y'],dta['z'],dta['l'])).transpose()
	
	# convert from RLE to pure RAW data
	return np.vstack([v[0]*[v[1:]] for v in rle ])

###------------------------------------------------------------------###
