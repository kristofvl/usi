# ess_algo.py
# author: Marko Borazio, Eugen Berlin for ESS, TU Darmstadt
# March 2014
# description:
# Sleep wake detection with a threshold based algorithm

import numpy as np
import sleeplab_helper as slh

###------------------------------------------------------------------###
# estimate sleep-wake segments with the ESS approach:
# hhgraw: 		raw sensor data from the wrist-worn device
# winwidth:		no of readings per second (here: 100Hz)
# nomothresh:	no motion threshold (here: 6.0)
def ess_sleep(hhgraw, winwidth, nomothresh, slthresh, usrno):
	# use only one axis
	foo = hhgraw[:,4]
	# calculate standard deviation over 1s 
	winvar = np.array([np.std(foo[i:i+winwidth]) for i in np.arange(0,len(foo)-winwidth,winwidth)])
	# check for non-movement according to the threshold
	nonmot = np.where( winvar < nomothresh )[0]
	# boundaries of non-movement sections
	bounds = np.where( np.diff(nonmot) > 1 )[0]
	# amount of seconds within non-movement sections
	slsnds = np.array([len(nonmot[bounds[k]+1:bounds[k+1]+1]) for k in range(len(bounds)-1)])
	
	# get indices for non-movement segments
	swest = np.zeros(len(hhgraw[::winwidth]),'uint8')
	indices = np.array([(nonmot[bounds[k]]-slsnds[k-1]+1, nonmot[bounds[k]]+1) for k in range(1,len(bounds))])
	
	# mark segments as sleep according to sleep threshold
	sblocks = indices[np.where(np.diff(indices) >= slthresh)[0]]
	for a,b in sblocks:
		swest[a:b] = 1
	
	return swest

###------------------------------------------------------------------###

###---MAIN---###

hhgpath = 'put the path to the HedgeHog data here'
annopath = 'put the path to the annotation file here'

fs = 100	# frequency of the inertial data
winwidth = 1*fs	# window size for calculating the var
nomo = [6.0]	# var threshold for non-movement detection
sleepthresh = [600] # sleep detection threshold of non-movement in [min] 

for nomothresh in nomo:
	usrlist = slh.get_userlist()
	print 'ESS'
	for slthresh in sleepthresh:
		
		print '###--- sleepthresh:',slthresh,'nomo:',nomothresh
		for i, usrno in enumerate(usrlist):
			print usrno
			hhgdta = np.load("%sp%s.npy"%(hhgpath,usrno)).view(np.recarray)
			gtdta  = np.load("%sp%s_anno.npy"%(annopath,usrno))
			hhgraw = slh.rle2raw(hhgdta)
			
			try:
				#estimate sleep
				swest = ess_sleep(hhgraw, winwidth, nomothresh, slthresh, usrno)
			except (ZeroDivisionError,ValueError) as e:
				print '##########---error:' , e
				continue