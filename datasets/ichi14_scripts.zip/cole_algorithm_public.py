# cole_algorithm_public.py
# author: Marko Borazio for ESS, TU Darmstadt
# March 2014
# description:
# Sleep/wake estimation by Cole's algorithm (Mini-Motionlogger)

import numpy as np
import sleeplab_helper as slh

###------------------------------------------------------------------###
def cole(bar, srate, elength):
	P = 0.0033
	W1 = 1.06
	W2 = 0.54 
	W3 = 0.58 
	W4 = 0.76 
	W5 = 2.3 
	W6 = 0.74 
	W7 = 0.67 
	
	ac = zc_cole(bar, srate, elength) #get activity count by zero crossing
	
	ws_arr = np.zeros(len(ac),'uint8')
	A = np.zeros(len(ac))
	for j, val in enumerate(ac[:]):
		if (j+13) >= len(ac):
			break
		
		#estimate sleep/awake by Cole's algorithm
		A[j+8] = P*((ac[j]+ac[j+1])*W1 + (ac[j+2]+ac[j+3])*W2 + (ac[j+4]+ac[j+5])*W3 + \
						(ac[j+6]+ac[j+7])*W4 + W5*(ac[j+8]+ac[j+9]) + (ac[j+10]+ac[j+11])*W6 + (ac[j+12]+ac[j+13])*W7)
		
		if A[j+8] < 1:
			#sleep
			ws_arr[j+8:j+9] = 1
	return ws_arr, A, ac
	
###------------------------------------------------------------------###
def zc_cole(bar, srate, elength):
	# check for zero crossings for each axis, return zero crossings count for epoch length
	schg = np.array([( np.where(np.diff(np.sign(bar['x'][i:i+srate])) != 0)[0].shape[0], \
						np.where(np.diff(np.sign(bar['y'][i:i+srate])) != 0)[0].shape[0], \
						np.where(np.diff(np.sign(bar['z'][i:i+srate])) != 0)[0].shape[0]) \
						for i in range(0,bar.shape[0]-srate,srate)])
	
	#30s epoch activity count
	return [np.sum(schg[cnt:cnt+elength,2]) for cnt in range(0,len(schg)-elength,elength)]
###------------------------------------------------------------------###

###---MAIN---###

hhgpath = 'put the path to the HedgeHog data here'
annopath = 'put the path to the annotation file here'

srate = 100 # sampling @ 100 Hz
elength = 30 #epoch length
lowcut = 0.5
highcut = 11.0
fs = 100.0
order = 1
ing = False

#load all patients
usrlist = slh.get_userlist()
	
confM = np.zeros([len(usrlist),2,2],int)
tot = np.zeros(len(usrlist),int)
slp = np.zeros([len(usrlist)+2,5],float)

for i, usrno in enumerate(usrlist):
	print usrno
	hhgdta = np.load("%sp%s.npy"%(hhgpath,usrno)) # get the HedgeHog data
	gtdta = np.load("%sp%s_anno.npy"%(annopath,usrno)) #get the ground truth
	hhgraw = slh.rle2raw(hhgdta) # get the raw data

	#apply Butterworth filter
	sfiltered = slh.butterworth(hhgraw[:,2:5], fs, lowcut, highcut, order, ing)
	try:
		# sleep estimation
		[swest, A, ac] = cole(sfiltered, srate, elength)
		
	except (ZeroDivisionError,ValueError) as e:
		print '##########---error:' , e
		continue
